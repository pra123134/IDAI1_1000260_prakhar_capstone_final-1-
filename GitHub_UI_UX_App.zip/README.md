# UI/UX Designs for Smart Restaurant Management App

This folder contains the user interface and experience designs for the Smart Restaurant Management App.
You can explore different screens, assets, and wireframes used in the app's design.
